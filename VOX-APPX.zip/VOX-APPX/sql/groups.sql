-- Run in Supabase SQL editor so Live group create can sync.
create table if not exists public.vox_groups (
  id text primary key,
  name text not null,
  owner_id uuid references auth.users(id),
  avatar_url text,
  created_at timestamptz default now()
);
create table if not exists public.vox_group_members (
  group_id text references public.vox_groups(id) on delete cascade,
  user_id uuid references auth.users(id) on delete cascade,
  primary key (group_id, user_id)
);
alter table public.vox_groups enable row level security;
alter table public.vox_group_members enable row level security;
drop policy if exists vox_groups_read on public.vox_groups;
create policy vox_groups_read on public.vox_groups for select using (true);
drop policy if exists vox_groups_ins on public.vox_groups;
create policy vox_groups_ins on public.vox_groups for insert with check (auth.uid() = owner_id);
drop policy if exists vox_gm_read on public.vox_group_members;
create policy vox_gm_read on public.vox_group_members for select using (true);
drop policy if exists vox_gm_ins on public.vox_group_members;
create policy vox_gm_ins on public.vox_group_members for insert with check (auth.uid() is not null);
