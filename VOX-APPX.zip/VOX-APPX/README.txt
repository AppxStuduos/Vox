VOX / APPX pack
===============

VOX.html         Chat app for users. Activate Plus/Pro here. No code maker inside.
VOX-codes.html   APPX-only generator. Keep this private.
vox-sw.js        Keep next to VOX.html for alerts.
README.txt       This file.
sql/groups.sql
sql/call-signals.sql

Plans
-----
Free   ₦0
Plus   ₦2,000 / month  or ₦18,000 / year
Pro    ₦5,000 / month  or ₦45,000 / year

After payment (09123834886):
1. Open VOX-codes.html
2. Make one Plus or Pro code
3. Send that code
4. User pastes it in VOX.html → You → VOX Plus → Activate plan

web/
  index.html     VOX site
  appx.html      APPX mission
  plus.html      prices
  styles.css
