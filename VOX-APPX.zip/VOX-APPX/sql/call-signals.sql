-- Run this in the Supabase SQL editor so missed call signals
-- can still reach the other phone if the live broadcast blips.

create table if not exists public.vox_call_signals (
  id uuid primary key default gen_random_uuid(),
  to_id text not null,
  from_id text,
  kind text,
  payload jsonb,
  created_at timestamptz default now()
);

create index if not exists vox_call_signals_to_id_created
  on public.vox_call_signals (to_id, created_at desc);

alter table public.vox_call_signals enable row level security;

drop policy if exists vox_call_signals_insert on public.vox_call_signals;
create policy vox_call_signals_insert
  on public.vox_call_signals for insert
  to authenticated
  with check (from_id = auth.uid()::text);

drop policy if exists vox_call_signals_select on public.vox_call_signals;
create policy vox_call_signals_select
  on public.vox_call_signals for select
  to authenticated
  using (to_id = auth.uid()::text);

-- Optional cleanup of old rows
-- delete from public.vox_call_signals where created_at < now() - interval '1 day';
