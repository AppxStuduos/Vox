/* VOX service worker — local + push-style notifications */
self.addEventListener('install', function(e){
  self.skipWaiting();
});
self.addEventListener('activate', function(e){
  e.waitUntil(self.clients.claim());
});
self.addEventListener('notificationclick', function(e){
  e.notification.close();
  var url = e.notification.data && e.notification.data.url;
  e.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(function(clients){
      for(var i=0;i<clients.length;i++){
        if(clients[i].focus) return clients[i].focus();
      }
      if(self.clients.openWindow) return self.clients.openWindow(url || './VOX-with-mods.html');
    })
  );
});
self.addEventListener('push', function(e){
  var data = {};
  try{ data = e.data ? e.data.json() : {}; }catch(err){
    try{ data = { body: e.data.text() }; }catch(e2){}
  }
  var title = data.title || 'VOX';
  var body = data.body || data.message || 'New activity';
  e.waitUntil(self.registration.showNotification(title, {
    body: body,
    tag: data.tag || 'vox-push',
    data: { url: data.url || './VOX-with-mods.html' },
    vibrate: [120, 60, 120]
  }));
});
self.addEventListener('message', function(e){
  var m = e.data || {};
  if(m.type === 'notify'){
    e.waitUntil(self.registration.showNotification(m.title || 'VOX', {
      body: m.body || '',
      tag: m.tag || 'vox',
      data: { url: m.url || './VOX-with-mods.html' },
      vibrate: [120, 60, 120]
    }));
  }
});
